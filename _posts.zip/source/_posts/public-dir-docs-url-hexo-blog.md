---
title: public_dir:docs;url:.../hexo-blog
date: 2023-01-22 22:38:17
tags: GitHub, url, public_dir
---
# Edited `_config.yml` を編集した
 - Set `public_dir` name as `docs` to make it the root directory of GitHub Pages.
 - Set `url` to ends with `hexo-blog` : the same as GitHub repository name.

## Countermeasure to preview with Live Server:
 - Made a symbolic link as named `hexo-blog` to point `docs` directory. 

## Unable to add `docs` directory recursively