---
title: 日付がずれるのでtimezoneを修正してみる
date: 2023-01-17 08:54:52
tags:
---
`_config.yml` の `timezone` を *Asia/Tokyo* に変更してみる。<span lang="en">('Asia' seems to need to start with a capital letter)</span>

