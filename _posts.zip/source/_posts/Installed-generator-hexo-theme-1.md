---
title: Installed 'generator-hexo-theme'
date: 2023-01-13 01:43:21
tags:
---
# Changed to a simple blog template
## About
<https://github.com/Yasukazu/blog/wiki/Hexo-Page-Generator/_edit>