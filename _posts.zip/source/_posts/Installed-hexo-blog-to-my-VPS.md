---
title: Installed _hexo-blog_ to my VPS
date: 2023-01-22 19:53:08
tags:
---
---
title: Install 'hexo-blog' to my VPS
date: 2023-01-22 17:48:53
tags: VPS
---
Hoped to login from VS Code to edit files and execute Hexo generate.
But the VPS terminal in VS Code freezed when installed VS Code plugins.
Why need for plugin: Live server to check rendered HTML.

Result: _Un-use-able_ because the remote(VPS) cuts its connection when _'Hexo generate'_ starts.