---
title: ts-doc wiki
date: 2022-11-30 15:36:52
tags:
---
This is rather about how to use *Hexo* static blog site genarator.
## Easy way to open the new post just created
Inside VS Code terminal, `hexo new "title"` creates a new post. Then, last output line shows an URL of the new post source file. Just move over the URL then [open with code] link appears. Clicking it, you can edit then new post with VS Code.