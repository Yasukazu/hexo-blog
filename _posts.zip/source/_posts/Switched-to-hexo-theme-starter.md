---
title: Switched to my fork of 'hexo-theme-starter'
date: 2023-01-24 15:30:44
tags: starter-theme
---
Felt to change my Hexo theme because current theme seemed too complicated to modify.

_starter_ theme looked simpler than current one.

At first, it had no style sheet.  So I tried to add a style sheet following the same way of the previous theme.
- Added `source/css/theme.css` file
- Added a stylesheet as `href=url_for('css/theme.css')` in `layout/_include/head.pug`