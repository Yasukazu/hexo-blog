---
title: Set 'blog' submodule as GitHub Pages
date: 2023-01-25 01:49:10
tags: GitHub-Pages
---
Since main branch of 'blog' submodule is 'dev', it matches to use GitHub Pages _'Deploy from branch'_.
Now it is public in _Internet_ as a web page at <https://yasukazu.github.io/blog/>.