---
title: Run Hexo 'npx' in Gitpod
date: 2023-01-12 07:08:40
tags:
---
In _Gitpod_, after workspace reboot, installed _hexo_ command is unavailable.
Countermeasure: use `npx` command as `npx hexo new post title`